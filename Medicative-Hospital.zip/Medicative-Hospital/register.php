<!DOCTYPE html> 
<html lang="en"> 
  
<head> 
    <meta charset="UTF-8"> 
    <link rel="stylesheet" href= 
"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
    <link rel="stylesheet" href="login.css"> 
    <title>Register Page</title> 
</head> 
<style> 
    .buttonwithhref {
            background-color: #2bdcd2;
            color: white;
            padding: 5px 10px;
            text-align: center;
            display: inline-block;
            font-size: 20px;
            margin: 10px 30px;
            cursor: pointer;
        }
    body { 
        margin: 0; 
        padding: 0; 
        font-family: sans-serif; 
        background: url() no-repeat; 
        background-size: cover; 
    } 
  
    .login-box { 
        width: 280px; 
        position: absolute; 
        top: 50%; 
        left: 50%; 
        transform: translate(-50%, -50%); 
        color: ; 
    } 
  
    .login-box h1 { 
        float: left; 
        font-size: 40px; 
  
        border-bottom: 4px solid #2bdcd2; 
        margin-bottom: 50px; 
        padding: 13px; 
    } 
  
    .textbox { 
        width: 100%; 
        overflow: hidden; 
        font-size: 20px; 
        padding: 8px 0; 
        margin: 8px 0; 
        border-bottom: 1px solid #2bdcd2;; 
    } 
  
    .fa { 
        width: px; 
        float: left; 
        text-align: center; 
    } 
  
    .textbox input { 
        border: none; 
        outline: none; 
        background: none; 
  
        font-size: 18px; 
        float: left; 
        margin: 0 10px; 
    } 
  
    .button { 
        width: 100%; 
        padding: 8px; 
        color:white; 
        background: none #2bdcd2;
        border: none; 
        border-radius: 6px; 
        font-size: 18px; 
        cursor: pointer; 
        margin: 12px 0; 
    } 
</style> 
<body> 
    <form action="" method="post"> 
        <div class="login-box"> 
            <h1>Register Here!</h1> 
  
            <div class="textbox"> 
                <i class="fa fa-user" aria-hidden="true"></i> 
                <input type="text" placeholder="Email"
                         name="email" value=""> 
            </div> 
            <div class="textbox"> 
                <i class="fa fa-user" aria-hidden="true"></i> 
                <input type="text" placeholder="FullName"
                         name="fullname" value=""> 
            </div> 
  
            <div class="textbox"> 
                <i class="fa fa-lock" aria-hidden="true"></i> 
                <input type="password" placeholder="Password"
                         name="password" value=""> 
            </div> 
            <div class="textbox"> 
                <i class="fa fa-lock" aria-hidden="true"></i> 
                <input type="password" placeholder="Renter Password"
                         name="repassword" value=""> 
            </div> 
  
            <input class="button" type="submit"
                     name="register" value="Register"><br><br>
            <center><button class="buttonwithhref" 
    onclick="window.location.href = 'http://127.0.0.1/MiniProject/dermat-div/Medicative-Hospital/login.php';" type="button">
        Want to Sign In?</button></center>
          
        </div> 
    </form> 
</body> 
  
</html> 

<?php
$conn=mysqli_connect('localhost','root','','miniproject');
if($conn)
{
#echo "Database: Connected succesfully"."<br>";
}
else
die("Could not connect".mysqli_connect_error);
if(isset($_POST['register']))
{
$email=$_POST['email'];
$fn=$_POST['fullname'];
$pass=$_POST['password'];
$repass=$_POST['repassword'];
if($repass==$pass)
{
$sql="INSERT INTO dermat VALUES ('$email','$fn','$pass','$repass')";
if(mysqli_query($conn,$sql))
{
    #mail($email,'Appointment Confirmation','Your appointment is confirmed','From: arunasridiyas5@gmail.com');
    echo '<script>alert("Registered Successfully")</script>';
    
}
else
{
echo "error in insertion".mysqli_error($conn);
}
}
else
{
echo '<script>alert("Password and Confirm Password do not match")</script>';
}
mysqli_close($conn);
}
?>






