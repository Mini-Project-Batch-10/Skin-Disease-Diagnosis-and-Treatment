<?php
 session_start();
?>
<!DOCTYPE html>
<html lang="en">



<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dermat</title>
    <script>(function(w, d) { w.CollectId = "6131ca89ef0a6c4814d2c4e8"; var h = d.head || d.getElementsByTagName("head")[0]; var s = d.createElement("script"); s.setAttribute("type", "text/javascript"); s.async=true; s.setAttribute("src", "https://collectcdn.com/launcher.js"); h.appendChild(s); })(window, document);</script>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- Responsive stylesheet  -->
    <link rel="stylesheet" type="text/css" href="css/responsive.css">

    <!-- Favicon -->
    <link href="img/favicon.png" rel="shortcut icon" type="image/png">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
 
<body>

    <div class="preloader"></div>

    <!-- Header navbar start -->
    <div class="header-topbar style-2">
        <div class="container padding-none">
            <div class="row">
                <div class="col-md-8 col-sm-6 welcome-top">
                    <ul class="list-inline top-icon">
                        <li><i class="fa fa-envelope"></i> dermat@gmail.com</li>
                        <li><i class="fa fa-clock-o"></i> Mon - Sat 8.00 - 18.00</li>
                    </ul>
                </div>
                <center><h3><?php echo "Hello ".$_SESSION['fullname'];?></h3></center>
                <div class="col-md-4 col-sm-6">
            
                </div>
            </div>
        </div>
    </div>

    <div class="main-navbar conner-style style-2 position-fixed">
        <div class="container padding-none">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-default">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand dis-none" href="welcome.php"><img src="dermat.PNG" alt="">
                                </a>
                            <a class="navbar-brand dis-block" href="welcome.php"><img src="dermat.PNG" alt="">
                                </a>
                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations-delay="1.8s" data-animations="fadeInUp">
                            <ul class="nav navbar-nav bg-none navbar-right style-3">
                                <li class="dropdown active">
                                    <a href="welcome.php" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Home">Home </span></a>
                        
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Depertment">Skin Diseases </span></a>
                                    <ul class="dropdown-menu pre-scrollable">
                                                    <li><a href="acne_rosacea.php">Acne and Rosacea</a>
                                        </li>
                                        <li><a href="Actinic%20Keratosis%20Basal%20Cell%20Carcinoma.php">Actinic Keratosis Basal Cell Carcinoma</a>
                                        </li>
                                        <li><a href="Atopic%20Dermatitis.php">Atopic Dermatitis</a>
                                        </li>
                                        <li><a href="Bullous%20Disease.php">Bullous Disease</a>
                                        </li>
                                        <li><a href="Bacterial%20Infection.php">Bacterial Infection</a>
                                        </li>
                                        <li><a href="Eczemo.php">Eczema</a>
                                        </li>
                                        <li><a href="Exanthems%20and%20Drug%20Eruptions.php">Exanthems and Drug Eruptions</a>
                                        </li>
                                        <li><a href="Hair%20Loss%20Alopecia.php">Hair Loss Alopecia</a>
                                        </li>
                                        <li><a href="Herpes%20HPV.php">Herpes HPV</a>
                                        </li><li><a href="Lupus%20Connective%20Tissue%20Diseases.php">Lupus Connective Tissue Diseases</a>
                                        </li><li><a href="Melanoma%20Skin%20Cancer.php">Melanoma Skin Cancer</a>
                                        </li><li><a href="Nail%20Fungus.php">Nail Fungus</a>
                                        </li><li><a href="Peeling.php">PeelingSkin</a>
                                        </li>
                                        <li><a href="Psoriasis.php">Psoriasis</a>
                                        </li>
                                        <li><a href="Scabies.php">Scabies</a>
                                        </li><li><a href="Seborrheic%20Keratoses.php">Seborrheic Keratoses</a>
                                        </li><li><a href="Systemic%20Disease.php">Systemic Disease</a>
                                        </li>
            <li><a href="Tinea%20RingWorm.php">Tinea RingWorm</a>
                                        </li><li><a href="Utricaria%20Hives.php">Utricaria Hives</a>
            </li><li><a href="Vitiligo.php">Vitiligo</a>
            
                                        </li><li><a href="Warts%20Molluscum.php">Warts Molluscum</a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                <li class="dropdown active">
                                    <a href="http://localhost:5000/"  role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Home">Skin Disease Identification</span> </a>
                        
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Depertment">Doctors for Consultation </span></a>
                                    <ul class="dropdown-menu pre-scrollable">
                                                <li><a href="doc_georgemiller.php">Doctor GeorgeMiller</a>
                                        </li>
                                        <li><a href="doc_moklesbeller.php">Doctor Moklesbeller</a>
                                        </li>
                                        <li><a href="doc_ravindhranadh.php">Doctor Ravindhranadh</a>
                                        </li>
                                        <li><a href="doc_siri.php">Doctor Siri</a>
                                        </li>
                                        <li><a href="doc_warner.php">Doctor Warner</a>
                                        </li>
                                        <li><a href="doc_wiliamson.php">Doctor Williamson</a>
                                        </li>
                                        <li><a href="appointment.php">Doctor's Appointment</a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a href="contact.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Depertment">Contact </span></a>
                                    <ul class="dropdown-menu pre-scrollable">
                                                <li><a href="contact.php">Contact Us</a>
                                        </li>
                                        <li><a href="reviews.php">Add Review</a>
                                        </li>
                                        <li><a href="allreviews.php">View Review</a>
                                        </li>
                                        
                                        
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a href="#" > <?php echo $_SESSION['fullname'];?></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="logout.php">Log Out</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <div class="dropdown-buttons">
                                        <div class="btn-group menu-search-box">
                                            <button type="button" class="btn dropdown-toggle" id="header-drop-3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon icon-Search"></i></button>
                                            <ul class="dropdown-menu dropdown-menu-right dropdown-animation" aria-labelledby="header-drop-3">
                                                <li>
                                                    <form role="search" class="search-box">
                                                        <div class="form-group">
                                                            <input type="text" class="form-control" placeholder="Search">
                                                            <i class="icon icon-Search form-control-feedback"></i>
                                                        </div>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Header navbar end -->

    <!-- Start  bootstrap-touch-slider Slider -->
    <div id="bootstrap-touch-slider" class="carousel bs-slider fade  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="5000" >

        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#bootstrap-touch-slider" data-slide-to="0" class="active"></li>
            <li data-target="#bootstrap-touch-slider" data-slide-to="1"></li>
            <li data-target="#bootstrap-touch-slider" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper For Slides -->
        <div class="carousel-inner" role="listbox">
            <!-- Third Slide -->
            <div class="item active">
                <!-- Slide Background -->
                <img src="img/bg/3.jpg" alt="Slider Images"  class="slide-image"/>
                <div class="bs-slider-overlay"></div>

                <div class="slide-text slide_style_left">
                    <h1 data-animation="animated fadeInRight"><span class="color-defult"> Dermat</span></h1>
                    <p data-animation="animated fadeInLeft">Our team of over 1000 doctors join me in giving you the best <br> of modern healthcare to ensure you stay healthy, always.</p>
                    <a href="#" target="_blank" class="btn btn-default" data-animation="animated fadeInLeft">Read more</a>
                    <a href="#" target="_blank"  class="btn btn-primary" data-animation="animated fadeInRight">Book Now</a>
                </div>
            </div>
            <!-- End of Slide -->

            <!-- Second Slide -->
            <div class="item">            
                <!-- Slide Background -->
                <img src="img/bg/2.jpg" alt="Slider Images" class="slide-image"/>
                <div class="bs-slider-overlay"></div>
                <!-- Slide Text Layer -->
                <div class="slide-text slide_style_center">
                    <h1 data-animation="animated bounceInDown"> Treat<span class="color-defult"> Skin</span> disease.</h1><br><br>
                    <a href="#" target="_blank" class="btn btn-default" data-animation="animated fadeInUp">Read More</a>
                </div>
            </div>
            <!-- End of Slide -->
            
            <!-- Third Slide -->
            <div class="item">            
                <!-- Slide Background -->
                <img src="img/bg/1.jpg" alt="Slider Images"  class="slide-image"/>
                <div class="bs-slider-overlay"></div>
                <!-- Slide Text Layer -->
                <div class="slide-text slide_style_right">
                    <h1 data-animation="animated fadeInLeft">Life Wellness<span class="color-defult"> Programs</span></h1>
                    <p data-animation="animated fadeInRight">Stay in touch and in shape with periodic tips from our <br>in-house  experts on wellness, fitness and nutrition.</p>
                    <a href="#" target="_blank" class="btn btn-default" data-animation="animated fadeInLeft">Read More</a>
                    <a href="#" target="_blank" class="btn btn-primary" data-animation="animated fadeInRight">Donate Now</a>
                </div>
            </div>
            <!-- End of Slide -->
        </div><!-- End of Wrapper For Slides -->

        <!-- Left Control -->
        <a class="left carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="prev">
            <span class="fa fa-angle-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <!-- Right Control -->
        <a class="right carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="next">
            <span class="fa fa-angle-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div> <!-- End  bootstrap-touch-slider Slider -->

    <!-- divider start -->
    <section class="about-3col animatedParent animateOnce">
        <div class="container">
            <div class="section-content">
                <div class="row">
                    <div class="about-feature style-2">
                        <center>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                            <div class="appointment-item">
                                <h5><a href="#">Our Doctors</a></h5>
                                <div class="line-border-center bg-gray margin-bottom-20"></div>
                                <p>Choose by name, specialty, city and more.</p>
                                <button class="btn btn-theme btn-sm">Find a Doctor </button>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4 center-block">
                            <div class="appointment-item">
                                <h5><a href="#">Appointments</a></h5>
                                <div class="line-border-center bg-gray margin-bottom-20"></div>
                                <p>Click in, walk in or call us today.</p>
                                <button class="btn btn-theme btn-sm">Get Appointment </button>
                            </div>
                        </div>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider end -->

    <!-- welcome start -->
    <section>
        <div class="container">
            <div class="section-content">
                <div class="row">
                    <div class="col-md-7">
                        <h2>Why chose us</h2>
                        <h3 class="color-defult">Get your skin ailment cured now</h3>
                        <p><span class="fw-b"> Skin diseases</span> are among the most common health problems worldwide and are associated with a considerable burden. The burden of skin disease is a multidimensional concept that encompasses psychological, social and financial consequences of the skin disease on the patients, their families and on society. Chronic and incurable skin diseases, such as psoriasis and eczema, are associated with significant morbidity in the form of physical discomfort and impairment of patients' quality of life; whereas malignant diseases, such as malignant melanoma, carry substantial mortality. With the availability of a wide range of health status and quality-of-life measures, the effects of most skin diseases on patients' lives can be measured efficiently. The aim of this review is to present some of the published data in order to highlight the magnitude of the burden associated with some common skin diseases and also to suggest ways to quantify this burden of skin disease.</p>

                    </div>
                    <div class="col-md-5">
                        <div>
                           <img alt="" src="img/services/w1.jpg"> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- welcome end -->

    <!-- service start -->
    <section class="service-area bg-f8 animatedParent animateOnce">
        <div class="container">
            <div class="section-title">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center">
                        <h2> <span class="color-defult">Skin Diseases Types</span></h2>
                        <div class="line-border-center bg-defult"></div>
                    </div>
                </div>
            </div>
   <div class="section-content">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Acne and Rosacea</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Actinic Keratosis Basal Cell Carcinoma</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Atopic Dermatitis</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                        </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Bullous Disease</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Bacterial Infection</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Eczema</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Exanthems and Drug Eruptions</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Hair Loss Alopecia</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Herpes HPV</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Lupus Connective Tissue Diseases</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Melanoma Skin Cancer</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Nail Fungus</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Poison Ivy</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Psoriasis</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Scabies</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Seborrheic Keratoses</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Systemic Disease</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Tinea RingWorm</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Utricaria Hives</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Vascular Tumors</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="service-item text-center style-3">
                            <span class="flaticon-heart-1"></span>
                            <h4><a href="#">Warts Molluscum</a></h4>
                            <div class="border-center"></div>
                            <button type="submit" class="btn btn-theme margin-top-20" data-text="Send Message">Read More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service end -->

    <!-- appointment start -->
    <section class=" animatedParent animateOnce">
        <div class="container padding-bottom-none">
            <div class="section-content">
                <div class="row">
                    <div class="col-md-6">
                        <img class="animated fadeInLeftShort slow delay-500 booking-cantact-img" src="img/bg/c1.png" alt="">
                    </div>
                    <div class="col-md-6 bg-f8 padding-tb margin-bottom-80 animated fadeInRightShort slow delay-500">
                        <div class="booking-from">
                            <h2>Make An <span class="color-defult">Appointment</span></h2>
                            <div class="border-style-2 margin-bottom-30"></div>
                            <form method="post" action="#">
                                <div class="row">
                                    <div class="col-md-6">
                                        <input type="text" name="name" id="fname" class="form-control" placeholder="First Name" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="name" id="lname" class="form-control" placeholder="Last Name" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="subject" class="form-control" placeholder="Input Subject" id="subject" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="Reservation" class="form-control" placeholder="Input Date" id="Reservation" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="email" name="email" class="form-control" placeholder="Your Email Here" id="email" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="phone" class="form-control" placeholder="Your Phone" id="phone" required>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="contact-textarea">
                                            <textarea class="form-control" rows="6" placeholder="Wright Message" id="message" name="message" required></textarea>
                                            <button class="btn btn-theme" type="submit" value="Submit Form">Send Message</button>
                                        </div>
                                    </div>
                                    <div id="form-messages"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- appointment end -->

   <!-- divider start -->
    <section class="service-area over-layer-default" style="background-image:url(img/bg/5.jpg);">
        <div class="container padding-bottom-none padding-top-40">
            <div class="section-content">
                <div class="row">
                    <div class="col-sm-12 col-md-4">
                        <div class="service-item style-1 text-white border-right">
                            <div class="service-icon">
                                <i class="pe-7s-call"></i>
                            </div>
                            <div class="content">
                                <h5><a href="#">Give us a Call</a></h5>
                                <p>+9712151488</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <div class="service-item style-1 text-white border-right">
                            <div class="">
                                <i class="pe-7s-mail-open"></i>
                            </div>
                            <div class="content">
                                <h5><a href="#">Send us a Message</a></h5>
                                <p>dermat@gmail.com</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <div class="service-item style-1 text-white">
                            <div class="">
                                <i class="pe-7s-map-marker"></i>
                            </div>
                            <div class="content">
                                <h5><a href="#">Visit our Instagram Page</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider end -->

     <!-- portfolio start -->
    <section class="gallery-area">
        <div class="container">
            <div class="section-title">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center">
                        <h2><span class="color-defult"> Image Gallery</span></h2>
                        <div class="line-border-center bg-defult"></div>
                    </div>
                </div>
            </div>
            <div class="section-content">
                <div class="row clearfix">
                    <div class="gallery-filter-item text-center">
                    </div>

                    <div class="gallery col-3 gutter">
                        <div class="gallery-item gp-two">
                            <div class="thumb">
                                <img src="img/portfolio/1.jpg" alt="">
                                <div class="gallery-hover">
                                    <div class="gallery-info">
                                        <div class="gallery-btn">
                                            <a href="img/portfolio/1.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"> <i class="pe-7s-graph2"></i>  </a>
                                        </div>
                                        <h4><a href="img/portfolio/1.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"</a></h4>
                                        <p><a href="#"></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="gallery-item gp-three">
                            <div class="thumb">
                                <img src="img/portfolio/2.jpg" alt="">
                                <div class="gallery-hover">
                                    <div class="gallery-info">
                                        <div class="gallery-btn">
                                            <a href="img/portfolio/2.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"> <i class="pe-7s-graph2"></i>  </a>
                                        </div>
                                        <h4><a href="img/portfolio/2.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"></a></h4>
                                        <p><a href="#"></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="gallery-item gp-four">
                            <div class="thumb">
                                <img src="img/portfolio/3.jpg" alt="">
                                <div class="gallery-hover">
                                    <div class="gallery-info">
                                        <div class="gallery-btn">
                                            <a href="img/portfolio/3.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"> <i class="pe-7s-graph2"></i>  </a>
                                        </div>
                                        <h4><a href="img/portfolio/3.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"></a></h4>
                                        <p><a href="#"></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="gallery-item gp-five">
                            <div class="thumb">
                                <img src="img/portfolio/4.jpg" alt="">
                                <div class="gallery-hover">
                                    <div class="gallery-info">
                                        <div class="gallery-btn">
                                            <a href="img/portfolio/4.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"> <i class="pe-7s-graph2"></i>  </a>
                                        </div>
                                        <h4><a href="img/portfolio/4.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"></a></h4>
                                        <p><a href="#"></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="gallery-item gp-two">
                            <div class="thumb">
                                <img src="img/portfolio/5.jpg" alt="">
                                <div class="gallery-hover">
                                    <div class="gallery-info">
                                        <div class="gallery-btn">
                                            <a href="img/portfolio/5.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"> <i class="pe-7s-graph2"></i>  </a>
                                        </div>
                                        <h4><a href="img/portfolio/5.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"> </a></h4>
                                        <p><a href="#"></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="gallery-item gp-three">
                            <div class="thumb">
                                <img src="img/portfolio/6.jpg" alt="">
                                <div class="gallery-hover">
                                    <div class="gallery-info">
                                        <div class="gallery-btn">
                                            <a href="img/portfolio/6.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"> <i class="pe-7s-graph2"></i>  </a>
                                        </div>
                                        <h4><a href="img/portfolio/6.jpg" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"></a></h4>
                                        <p><a href="#"></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- portfolio end -->

   <!-- divider start -->
    <section class="divider divider-video over-layer-white" style="background-image:url(img/bg/6.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <a href="https://youtu.be/vX-lG9nb1fU" data-fancybox-group="gallery" class="lightbox-image" title="lightbox view"><i class="icon icon-Play"></i></a>    
                </div> 
            </div> 
        </div> 
    </section>
    <!-- divider end -->
    <!-- Team start -->
    <section class="team-area">
        <div class="container">
            <div class="section-title">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center">
                        <h2><span class="color-defult">Experience</span> Doctor</h2>
                        <div class="line-border-center bg-defult"></div>
                        <p>We have good Experienced Dermatologists Here</p>
                    </div>
                </div>
            </div>
            <div class="section-content">
                <div class="row">
                    <div class="team-carousel">
                        <div class="item">
                            <div class="team-item-2">
                                <img src="img/team/1.png" alt="">
                                <div class="team-contact">
                                </div>
                                <div class="team-content">
                                    <h4>Dr. Mokles Beller</h4>
                                    <h6>Dermatologist</h6>
                                    <div class="team-content-icon">
                                        <i class="flaticon-heart"></i>
                                    </div>
                                </div>
                                <div class="timetable">
                                    <div class="item">
                                        <div class="label">Monday-Friday</div>
                                        <div class="value">08:00 - 17:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Saturday</div>
                                        <div class="value">10:00 - 16:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Sunday</div>
                                        <div class="value">12:00 - 14:00</div>
                                    </div>
                                    <a href="doc_moklesbeller.html" class="btn-theme text-center btn-block"> View Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="team-item-2">
                                <img src="img/team/2.png" alt="">
                                <div class="team-contact">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-behance"></i></a></li>
                                    </ul>
                                </div>
                                <div class="team-content">
                                    <h4>Dr. George miller</h4>
                                    <h6>Dermatologist</h6>
                                    <div class="team-content-icon">
                                        <i class="flaticon-heart"></i>
                                    </div>
                                </div>
                                <div class="timetable">
                                    <div class="item">
                                        <div class="label">Monday-Friday</div>
                                        <div class="value">08:00 - 17:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Saturday</div>
                                        <div class="value">9:00 - 16:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Sunday</div>
                                        <div class="value">12:00 - 14:00</div>
                                    </div>
                                    <a href="doc_georgemiller.html" class="btn-theme text-center btn-block"> View Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="team-item-2">
                                <img src="img/team/3.png" alt="">
                                <div class="team-contact">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-behance"></i></a></li>
                                    </ul>
                                </div>
                                <div class="team-content">
                                    <h4>Dr.ravindhranadh</h4>
                                    <h6>Dermatologist</h6>
                                    <div class="team-content-icon">
                                        <i class="flaticon-heart"></i>
                                    </div>
                                </div>
                                <div class="timetable">
                                    <div class="item">
                                        <div class="label">Monday-Friday</div>
                                        <div class="value">09:00 - 17:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Saturday</div>
                                        <div class="value">11:00 - 16:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Sunday</div>
                                        <div class="value">8:00 - 14:00</div>
                                    </div>
                                    <a href="doc_ravindhranadh.html" class="btn-theme text-center btn-block"> View Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="team-item-2">
                                <img src="img/team/4.png" alt="">
                                <div class="team-contact">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-behance"></i></a></li>
                                    </ul>
                                </div>
                                <div class="team-content">
                                    <h4>Dr. warner</h4>
                                    <h6>Dermatologist</h6>
                                    <div class="team-content-icon">
                                        <i class="flaticon-heart"></i>
                                    </div>
                                </div>
                                <div class="timetable">
                                    <div class="item">
                                        <div class="label">Monday-Friday</div>
                                        <div class="value">09:00 - 17:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Saturday</div>
                                        <div class="value">12:00 - 16:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Sunday</div>
                                        <div class="value">9:00 - 14:00</div>
                                    </div>
                                    <a href="doc_warner.html" class="btn-theme text-center btn-block"> View Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="team-item-2">
                                <img src="img/team/5.png" alt="">
                                <div class="team-contact">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-behance"></i></a></li>
                                    </ul>
                                </div>
                                <div class="team-content">
                                    <h4>Dr.siri</h4>
                                    <h6>Dermatologist</h6>
                                    <div class="team-content-icon">
                                        <i class="flaticon-heart"></i>
                                    </div>
                                </div>
                                <div class="timetable">
                                    <div class="item">
                                        <div class="label">Monday-Friday</div>
                                        <div class="value">08:00 - 17:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Saturday</div>
                                        <div class="value">10:00 - 16:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Sunday</div>
                                        <div class="value">12:00 - 14:00</div>
                                    </div>
                                    <a href="doc_siri.html" class="btn-theme text-center btn-block"> View Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="team-item-2">
                                <img src="https://post.healthline.com/wp-content/uploads/2019/01/Male_Doctor_732x549-thumbnail.jpg" alt="">
                                <div class="team-contact">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-behance"></i></a></li>
                                    </ul>
                                </div>
                                <div class="team-content">
                                    <h4><a href="#">Dr. wiliamson</a></h4>
                                    <h6>Dermatologist</h6>
                                    <div class="team-content-icon">
                                        <i class="flaticon-heart"></i>
                                    </div>
                                </div>
                                <div class="timetable">
                                    <div class="item">
                                        <div class="label">Monday-Friday</div>
                                        <div class="value">08:00 - 17:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Saturday</div>
                                        <div class="value">10:00 - 16:00</div>
                                    </div>
                                    <div class="item">
                                        <div class="label">Sunday</div>
                                        <div class="value">12:00 - 14:00</div>
                                    </div>
                                    <a href="doc_wiliamson.html" class="btn-theme text-center btn-block"> View Profile</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Team end -->



    <!-- Testimonial start -->
    <section class="testimonial">
        <div class="container">
            <div class="section-title">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center">
                        <h2>Our <span class="color-defult"> Clients</span> Say</h2>
                        <div class="line-border-center bg-defult"></div>
                        <p>Repellendus error placeat numquam doloribus perferendis consequatur maxime molestiae soluta Corporis quidem quaerat accusantium omnis repudiandae nulla recusandae</p>
                    </div>
                </div>
            </div>
            <div class="section-content">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="testimonial-carousel-one">
                            <div class="item">
                                <div class="testimonial-item text-center">
                                    <div class="testimonial-author">
                                        <div class="author-img">
                                            <img class="img-responsive" src="img/testimonial/1.png" alt="" />
                                        </div>
                                        <h4>John Daniel</h4>
                                        <h6>business man</h6>
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <p>consectetur adipisicing elit. Nemo ex doloremque maiores quas, cumque commodi eaque molestiae in ratione nam obcaecati nihil provident illum eius sed ullam amet, expedita molestias iusto.</p> 
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-item text-center">
                                    <div class="testimonial-author">
                                        <div class="author-img">
                                            <img class="img-responsive" src="img/testimonial/2.png" alt="" />
                                        </div>
                                        <h4>John Daniel</h4>
                                        <h6>business man</h6>
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <p>consectetur adipisicing elit. Nemo ex doloremque maiores quas, cumque commodi eaque molestiae in ratione nam obcaecati nihil provident illum eius sed ullam amet, expedita molestias iusto.</p> 
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-item text-center">
                                    <div class="testimonial-author">
                                        <div class="author-img">
                                            <img class="img-responsive" src="img/testimonial/3.png" alt="" />
                                        </div>
                                        <h4>John Daniel</h4>
                                        <h6>business man</h6>
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <p>consectetur adipisicing elit. Nemo ex doloremque maiores quas, cumque commodi eaque molestiae in ratione nam obcaecati nihil provident illum eius sed ullam amet, expedita molestias iusto.</p> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonial end -->
    

   
  
    <a href="#" class="scrollup"><i class="pe-7s-up-arrow" aria-hidden="true"></i></a>
    <!-- jQuery -->
    <script type="text/javascript" src="js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- all plugins and JavaScript -->
    <script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="js/css3-animate-it.js"></script>
    <script type="text/javascript" src="js/bootstrap-dropdownhover.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/gallery.js"></script>
    <script type="text/javascript" src="js/player.min.js"></script>
    <script type="text/javascript" src="js/retina.js"></script>
    <script type="text/javascript" src="js/comming-soon.js"></script>

    <!-- Main Custom JS -->
    <script type="text/javascript" src="js/script.js"></script>


</body>



</html>

