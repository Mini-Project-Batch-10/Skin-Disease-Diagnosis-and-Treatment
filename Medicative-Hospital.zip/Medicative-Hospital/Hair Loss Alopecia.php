<!DOCTYPE html>
<html lang="en">

<?php
session_start();
?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Medicative Hospital || Health & Medical HTML Template</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- Responsive stylesheet  -->
    <link rel="stylesheet" type="text/css" href="css/responsive.css">

    <!-- Favicon -->
    <link href="img/favicon.png" rel="shortcut icon" type="image/png">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="preloader"></div>

    <!-- Header navbar start -->
    <div class="header-topbar style-2">
        <div class="container padding-none">
            <div class="row">
                <div class="col-md-8 col-sm-6 welcome-top">
                    <ul class="list-inline top-icon">
                        <li><i class="fa fa-envelope"></i> dermat@gmail.com</li>
                        <li><i class="fa fa-clock-o"></i> Mon - Sat 8.00 - 18.00</li>
                    </ul>
                </div>
                <center><h3><?php echo "Hello ".$_SESSION['fullname'];?></h3></center>
                <div class="col-md-4 col-sm-6">
            
                </div>
            </div>
        </div>
    </div>

    <div class="main-navbar conner-style style-2 position-fixed">
        <div class="container padding-none">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-default">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand dis-none" href="welcome.php"><img src="dermat.PNG" alt="">
                                </a>
                            <a class="navbar-brand dis-block" href="welcome.php"><img src="dermat.PNG" alt="">
                                </a>
                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations-delay="1.8s" data-animations="fadeInUp">
                            <ul class="nav navbar-nav bg-none navbar-right style-3">
                                <li class="dropdown active">
                                    <a href="welcome.php" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Home">Home </span></a>
                        
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Depertment">Skin Diseases </span></a>
                                    <ul class="dropdown-menu pre-scrollable">
                                                    <li><a href="acne_rosacea.php">Acne and Rosacea</a>
                                        </li>
                                        <li><a href="Actinic%20Keratosis%20Basal%20Cell%20Carcinoma.php">Actinic Keratosis Basal Cell Carcinoma</a>
                                        </li>
                                        <li><a href="Atopic%20Dermatitis.php">Atopic Dermatitis</a>
                                        </li>
                                        <li><a href="Bullous%20Disease.php">Bullous Disease</a>
                                        </li>
                                        <li><a href="Bacterial%20Infection.php">Bacterial Infection</a>
                                        </li>
                                        <li><a href="Eczemo.php">Eczema</a>
                                        </li>
                                        <li><a href="Exanthems%20and%20Drug%20Eruptions.php">Exanthems and Drug Eruptions</a>
                                        </li>
                                        <li><a href="Hair%20Loss%20Alopecia.php">Hair Loss Alopecia</a>
                                        </li>
                                        <li><a href="Herpes%20HPV.php">Herpes HPV</a>
                                        </li><li><a href="Lupus%20Connective%20Tissue%20Diseases.php">Lupus Connective Tissue Diseases</a>
                                        </li><li><a href="Melanoma%20Skin%20Cancer.php">Melanoma Skin Cancer</a>
                                        </li><li><a href="Nail%20Fungus.php">Nail Fungus</a>
                                        </li><li><a href="Peeling.php">PeelingSkin</a>
                                        </li>
                                        <li><a href="Psoriasis.php">Psoriasis</a>
                                        </li>
                                        <li><a href="Scabies.php">Scabies</a>
                                        </li><li><a href="Seborrheic%20Keratoses.php">Seborrheic Keratoses</a>
                                        </li><li><a href="Systemic%20Disease.php">Systemic Disease</a>
                                        </li>
            <li><a href="Tinea%20RingWorm.php">Tinea RingWorm</a>
                                        </li><li><a href="Utricaria%20Hives.php">Utricaria Hives</a>
            </li><li><a href="Vitiligo.php">Vitiligo</a>
            
                                        </li><li><a href="Warts%20Molluscum.php">Warts Molluscum</a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                <li class="dropdown active">
                                    <a href="http://localhost:5000/"  role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Home">Skin Disease Identification</span> </a>
                        
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Depertment">Doctors for Consultation </span></a>
                                    <ul class="dropdown-menu pre-scrollable">
                                                <li><a href="doc_georgemiller.php">Doctor GeorgeMiller</a>
                                        </li>
                                        <li><a href="doc_moklesbeller.php">Doctor Moklesbeller</a>
                                        </li>
                                        <li><a href="doc_ravindhranadh.php">Doctor Ravindhranadh</a>
                                        </li>
                                        <li><a href="doc_siri.php">Doctor Siri</a>
                                        </li>
                                        <li><a href="doc_warner.php">Doctor Warner</a>
                                        </li>
                                        <li><a href="doc_wiliamson.php">Doctor Williamson</a>
                                        </li>
                                        <li><a href="appointment.php">Doctor's Appointment</a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a href="contact.php" role="button" aria-haspopup="true" aria-expanded="false"><span data-hover="Contact">Contact </span></a>
                                
                                </li>
                                <li class="dropdown">
                                    <a href="#" > <?php echo $_SESSION['fullname'];?></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="logout.php">Log Out</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <div class="dropdown-buttons">
                                        <div class="btn-group menu-search-box">
                                            <button type="button" class="btn dropdown-toggle" id="header-drop-3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon icon-Search"></i></button>
                                            <ul class="dropdown-menu dropdown-menu-right dropdown-animation" aria-labelledby="header-drop-3">
                                                <li>
                                                    <form role="search" class="search-box">
                                                        <div class="form-group">
                                                            <input type="text" class="form-control" placeholder="Search">
                                                            <i class="icon icon-Search form-control-feedback"></i>
                                                        </div>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Header navbar end -->
    <section class="inner-bg over-layer-black" style="background-image: url('img/bg/4.jpg')">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="mini-title inner-style-2">
                        <h3>Hair Loss Alopecia</h3>
                        <p><a href="index.html">Home</a> <span class="fa fa-angle-right"></span> <a href="Hair Loss Alopecia.html"</a>Hair Loss Alopecia</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- depertment start -->
    <section class="depertment-area">
        <div class="container">
            <div class="section-content">
                <div class="row">
                    <div class="col-md-8">
                        <img src="img/hair.png" alt="">
                        <h3 class="margin-top-30 margin-bottom-20"> <span class="color-defult">Hair Loss Alopecia</span> </h3>
                       <p> <span class="color-defult">Alopecia areata is a condition that causes hair to fall out in small patches, which can be unnoticeable. These patches may connect, however, and then become noticeable. The condition develops when the immune system attacks the hair follicles, resulting in hair loss.Sudden hair loss may occur on the scalp, and in some cases the eyebrows, eyelashes, and face, as well as other parts of the body. It can also develop slowly and recur after years between instances.</div>
    </section>
    <!-- depertment end -->

    
    <!-- divider start -->
    <section class="service-area over-layer-default" style="background-image:url(img/bg/5.jpg);">
        <div class="container padding-bottom-none padding-top-40">
            <div class="section-content">
                <div class="row">
                    <div class="col-sm-12 col-md-4">
                        <div class="service-item style-1 text-white border-right">
                            <div class="service-icon">
                                <i class="pe-7s-call"></i>
                            </div>
                            <div class="content">
                                <h5><a href="#">Give us a Call</a></h5>
                                <p>+9712151488</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <div class="service-item style-1 text-white border-right">
                            <div class="">
                                <i class="pe-7s-mail-open"></i>
                            </div>
                            <div class="content">
                                <h5><a href="#">Send us a Message</a></h5>
                                <p>dermat@gmail.com</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <div class="service-item style-1 text-white">
                            <div class="">
                                <i class="pe-7s-map-marker"></i>
                            </div>
                            <div class="content">
                                <h5><a href="#">Visit our Instagram Page</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider end -->
    <a href="#" class="scrollup"><i class="pe-7s-up-arrow" aria-hidden="true"></i></a>
    <!-- jQuery -->
    <script type="text/javascript" src="js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- all plugins and JavaScript -->
    <script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="js/css3-animate-it.js"></script>
    <script type="text/javascript" src="js/bootstrap-dropdownhover.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/gallery.js"></script>
    <script type="text/javascript" src="js/player.min.js"></script>
    <script type="text/javascript" src="js/retina.js"></script>
    <script type="text/javascript" src="js/comming-soon.js"></script>

    <!-- Main Custom JS -->
    <script type="text/javascript" src="js/script.js"></script>


</body>



</html>
